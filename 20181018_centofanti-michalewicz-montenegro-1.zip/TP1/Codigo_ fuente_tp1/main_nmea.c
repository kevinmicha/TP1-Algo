#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <ctype.h>

#ifndef COMMAND__H
#include "command_arg.h"
#endif

#ifndef READ__H
#include "read_nmea.h"
#endif

#ifndef DISPLAY__H
#include "display_gpx.h"
#endif

int main(int argc, const char *argv[]) {

	metadata_t metadata;
	status_t arg_validation, read_val;
	trackpt_t trackpt;
	char statement[MAX_STR_NMEA], *pos_ptr;

	if((arg_validation = validate_argv(argc, argv)) == ST_DATA_ERR) {
		print_help();
		return EXIT_FAILURE;
	}
	if(arg_validation == ST_HELP){
		print_help();
		return EXIT_SUCCESS;
	}

	if(read_time_argv(argc, argv, &(metadata.meta_time)) != ST_OK) {
		print_help();
		return EXIT_FAILURE;
	}

	if(read_name_argv(argc, argv, &metadata) != ST_OK) {
		print_help();
		return EXIT_FAILURE;
	}
	
	print_header();
	display_metadata(&metadata);
	print_opening_tags();

	do {
		read_val = read_nmea(&statement);
		if(read_val == ST_OK){
			pos_ptr = statement;
			if(time_of_fix(&pos_ptr, &trackpt, metadata.meta_time) != ST_OK);
			else if(latitude(&pos_ptr, &trackpt.latitude) != ST_OK);
			else if(longitude(&pos_ptr, &trackpt.longitude) != ST_OK);
			else if(quality_of_fix(&pos_ptr, &trackpt.quality) != ST_OK);
			else if(num_of_satellites(&pos_ptr, &trackpt.n_sat) != ST_OK);
			else if(hdop(&pos_ptr, &trackpt.hdop) != ST_OK);
			else if(elevation(&pos_ptr, &trackpt.elevation) != ST_OK);
			else if(undulation_of_geoid(&pos_ptr, &trackpt.undulation_of_geoid) == ST_OK){
				display_track_point(&trackpt);
			}
		}
	} while(read_val != ST_EOF);

	print_closing_tags();

	return EXIT_SUCCESS;
}